package br.com.caelum.contas.modelo;

public enum TipoDaConta {
	ENTRADA,
	SAIDA
}
